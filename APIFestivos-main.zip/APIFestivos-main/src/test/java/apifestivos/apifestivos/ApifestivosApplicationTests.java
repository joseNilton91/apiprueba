package apifestivos.apifestivos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApifestivosApplicationTests {

	@Test
	void contextLoads() {
	}

}
