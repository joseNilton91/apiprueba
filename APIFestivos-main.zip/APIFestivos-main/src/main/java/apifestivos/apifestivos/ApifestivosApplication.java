package apifestivos.apifestivos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ApifestivosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApifestivosApplication.class, args);
	}

}
